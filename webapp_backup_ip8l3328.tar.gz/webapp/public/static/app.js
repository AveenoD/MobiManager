/* ============================================
   MobiManager — Premium landing page interactions
   Progressive enhancement: every feature has a fallback.
   ============================================ */

(function () {
  'use strict'

  // -----------------------------
  // Helpers
  // -----------------------------
  const $ = (sel, root) => (root || document).querySelector(sel)
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel))
  const on = (el, ev, fn, opts) => el && el.addEventListener(ev, fn, opts || false)

  const prefersReducedMotion =
    window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches

  const isTouch = window.matchMedia && window.matchMedia('(hover: none)').matches

  // -----------------------------
  // 1. Reveal animations (IntersectionObserver)
  //    We add `.anim-ready` to <html> so [data-anim] elements
  //    fade in. Without JS, content stays visible (fail-safe).
  // -----------------------------
  function initReveal() {
    if (prefersReducedMotion) return
    document.documentElement.classList.add('anim-ready')

    const items = $$('[data-anim]')
    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'))
      return
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target
            const delay = parseFloat(el.getAttribute('data-anim-delay') || '0')
            el.style.transitionDelay = delay + 's'
            el.classList.add('is-visible')
            io.unobserve(el)
          }
        })
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    )
    items.forEach((el) => io.observe(el))

    // Safety: if for some reason the observer never fires within 2s, force-show
    setTimeout(() => {
      items.forEach((el) => {
        if (!el.classList.contains('is-visible')) el.classList.add('is-visible')
      })
    }, 2000)
  }

  // -----------------------------
  // 2. Scroll progress bar
  // -----------------------------
  function initScrollProgress() {
    const bar = $('#scroll-progress')
    if (!bar) return
    let ticking = false
    function update() {
      const h = document.documentElement
      const max = (h.scrollHeight - h.clientHeight) || 1
      const pct = Math.min(100, Math.max(0, (h.scrollTop / max) * 100))
      bar.style.width = pct + '%'
      ticking = false
    }
    on(window, 'scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(update)
        ticking = true
      }
    }, { passive: true })
    update()
  }

  // -----------------------------
  // 3. Navbar scroll state + mobile menu
  // -----------------------------
  function initNavbar() {
    const nav = $('#site-navbar')
    if (nav) {
      const onScroll = () => {
        if (window.scrollY > 16) nav.classList.add('is-scrolled')
        else nav.classList.remove('is-scrolled')
      }
      onScroll()
      on(window, 'scroll', onScroll, { passive: true })
    }

    const btn = $('#mobile-menu-btn')
    const menu = $('#mobile-menu')
    if (btn && menu) {
      on(btn, 'click', () => {
        menu.classList.toggle('is-open')
        const open = menu.classList.contains('is-open')
        btn.innerHTML = open
          ? '<i class="fas fa-xmark text-white/80"></i>'
          : '<i class="fas fa-bars text-white/80"></i>'
        btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu')
      })
      // Close on link click
      $$('#mobile-menu a').forEach((a) =>
        on(a, 'click', () => {
          menu.classList.remove('is-open')
          btn.innerHTML = '<i class="fas fa-bars text-white/80"></i>'
        })
      )
    }
  }

  // -----------------------------
  // 4. Sticky CTA show after hero scrolled past
  // -----------------------------
  function initStickyCTA() {
    const cta = $('#sticky-cta')
    if (!cta) return
    const onScroll = () => {
      if (window.scrollY > 700) cta.classList.add('is-visible')
      else cta.classList.remove('is-visible')
    }
    onScroll()
    on(window, 'scroll', onScroll, { passive: true })
  }

  // -----------------------------
  // 5. Custom cursor (desktop only)
  // -----------------------------
  function initCursor() {
    if (isTouch || prefersReducedMotion) return
    const dot = $('#cursor-dot')
    const ring = $('#cursor-ring')
    if (!dot || !ring) return
    let mx = 0, my = 0, rx = 0, ry = 0
    on(window, 'mousemove', (e) => {
      mx = e.clientX; my = e.clientY
      dot.style.transform = `translate(${mx}px, ${my}px) translate(-50%, -50%)`
    })
    function loop() {
      rx += (mx - rx) * 0.18
      ry += (my - ry) * 0.18
      ring.style.transform = `translate(${rx}px, ${ry}px) translate(-50%, -50%)`
      requestAnimationFrame(loop)
    }
    loop()

    const hoverables = 'a, button, input, textarea, select, [role="button"], label, .feature-card, .demo-step'
    $$(hoverables).forEach((el) => {
      on(el, 'mouseenter', () => ring.classList.add('is-hover'))
      on(el, 'mouseleave', () => ring.classList.remove('is-hover'))
    })
  }

  // -----------------------------
  // 6. Interactive demo (repair pipeline)
  // -----------------------------
  function initDemo() {
    const steps = $$('#demo-steps .demo-step')
    if (!steps.length) return

    const stages = [
      {
        status: 'RECEIVED', pillCls: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
        progress: 25,
        msg: '<i class="fas fa-info-circle text-blue-300 mr-2"></i> Customer dropped off device. Diagnosis: cracked screen.',
        profit: false,
      },
      {
        status: 'IN_REPAIR', pillCls: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
        progress: 55,
        msg: '<i class="fas fa-screwdriver-wrench text-amber-300 mr-2"></i> Assigned to Tech-2. Replacement screen in stock. ETA 2 hours.',
        profit: false,
      },
      {
        status: 'REPAIRED', pillCls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
        progress: 80,
        msg: '<i class="fas fa-bell text-emerald-300 mr-2"></i> Repair complete. Pickup-pending alert sent to customer via SMS.',
        profit: false,
      },
      {
        status: 'DELIVERED', pillCls: 'bg-violet-500/15 text-violet-300 border-violet-500/30',
        progress: 100,
        msg: '<i class="fas fa-circle-check text-violet-300 mr-2"></i> Device delivered. Profit posted to today\'s P&L.',
        profit: true,
      },
    ]

    const pill = $('#demo-status-pill')
    const bar = $('#demo-progress')
    const msgBox = $('#demo-message')
    const profitBox = $('#demo-profit')
    const prevBtn = $('#demo-prev')
    const nextBtn = $('#demo-next')
    const resetBtn = $('#demo-reset')

    let idx = 0

    function render() {
      const st = stages[idx]
      steps.forEach((s, i) => {
        s.classList.toggle('is-active', i === idx)
        s.classList.toggle('is-done', i < idx)
      })
      if (pill) {
        pill.className = 'px-3 py-1.5 rounded-full text-xs font-semibold border ' + st.pillCls
        pill.textContent = st.status
      }
      if (bar) bar.style.width = st.progress + '%'
      if (msgBox) msgBox.innerHTML = st.msg
      if (profitBox) profitBox.style.opacity = st.profit ? '1' : '0.5'
      if (prevBtn) prevBtn.disabled = idx === 0
      if (nextBtn) {
        nextBtn.innerHTML = idx === stages.length - 1
          ? 'Restart <i class="fas fa-rotate-right ml-1.5"></i>'
          : 'Next step <i class="fas fa-chevron-right ml-1.5"></i>'
      }
    }

    on(nextBtn, 'click', () => {
      idx = idx === stages.length - 1 ? 0 : idx + 1
      render()
    })
    on(prevBtn, 'click', () => {
      idx = Math.max(0, idx - 1)
      render()
    })
    on(resetBtn, 'click', () => { idx = 0; render() })
    steps.forEach((s, i) => on(s, 'click', () => { idx = i; render() }))

    render()

    // Auto-advance once when scrolled into view
    if ('IntersectionObserver' in window && !prefersReducedMotion) {
      const demoSection = $('#demo')
      let played = false
      const io = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting && !played) {
            played = true
            let count = 0
            const id = setInterval(() => {
              count++
              if (idx < stages.length - 1) { idx++; render() }
              if (count >= stages.length - 1) clearInterval(id)
            }, 1500)
          }
        })
      }, { threshold: 0.4 })
      if (demoSection) io.observe(demoSection)
    }
  }

  // -----------------------------
  // 7. Code tabs (Developer section)
  // -----------------------------
  function initCodeTabs() {
    const tabs = $$('.code-tab')
    if (!tabs.length) return
    const panes = $$('.code-pane')

    function activate(name) {
      tabs.forEach((t) => {
        const active = t.getAttribute('data-tab') === name
        t.classList.toggle('is-active', active)
        if (active) {
          t.classList.add('bg-white/10', 'text-white')
          t.classList.remove('text-white/55')
        } else {
          t.classList.remove('bg-white/10', 'text-white')
          t.classList.add('text-white/55')
        }
      })
      panes.forEach((p) => {
        p.classList.toggle('hidden', p.getAttribute('data-pane') !== name)
      })
    }
    tabs.forEach((t) =>
      on(t, 'click', () => activate(t.getAttribute('data-tab')))
    )

    // Copy-to-clipboard
    const copyBtn = $('#copy-code')
    const copyLabel = $('#copy-label')
    on(copyBtn, 'click', () => {
      const visible = $$('.code-pane').find((p) => !p.classList.contains('hidden'))
      const text = visible ? (visible.textContent || '').trim() : ''
      const done = () => {
        if (copyLabel) {
          const orig = copyLabel.textContent
          copyLabel.textContent = 'Copied!'
          setTimeout(() => { copyLabel.textContent = orig }, 1400)
        }
      }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done).catch(fallback)
        } else {
          fallback()
        }
      } catch (e) { fallback() }

      function fallback() {
        try {
          const ta = document.createElement('textarea')
          ta.value = text
          ta.style.position = 'fixed'; ta.style.opacity = '0'
          document.body.appendChild(ta)
          ta.select()
          document.execCommand('copy')
          document.body.removeChild(ta)
          done()
        } catch (e) {
          if (copyLabel) {
            copyLabel.textContent = 'Press Ctrl+C'
            setTimeout(() => { copyLabel.textContent = 'Copy' }, 1600)
          }
        }
      }
    })
  }

  // -----------------------------
  // 8. FAQ accordion
  // -----------------------------
  function initFAQ() {
    const items = $$('.faq-item')
    items.forEach((item) => {
      const trigger = $('.faq-trigger', item)
      on(trigger, 'click', () => {
        const open = item.classList.contains('is-open')
        // Close all
        items.forEach((i) => {
          i.classList.remove('is-open')
          const t = $('.faq-trigger', i)
          if (t) t.setAttribute('aria-expanded', 'false')
        })
        if (!open) {
          item.classList.add('is-open')
          trigger.setAttribute('aria-expanded', 'true')
        }
      })
    })
  }

  // -----------------------------
  // 9. Pricing monthly/yearly toggle
  // -----------------------------
  function initPricing() {
    const monthlyBtn = $('#bill-monthly')
    const yearlyBtn = $('#bill-yearly')
    if (!monthlyBtn || !yearlyBtn) return

    function setMode(mode) {
      const yearly = mode === 'yearly'
      monthlyBtn.classList.toggle('is-active', !yearly)
      yearlyBtn.classList.toggle('is-active', yearly)

      if (!yearly) {
        monthlyBtn.classList.add('bg-white', 'text-ink-900')
        monthlyBtn.classList.remove('text-white/70')
        yearlyBtn.classList.remove('bg-white', 'text-ink-900')
        yearlyBtn.classList.add('text-white/70')
      } else {
        yearlyBtn.classList.add('bg-white', 'text-ink-900')
        yearlyBtn.classList.remove('text-white/70')
        monthlyBtn.classList.remove('bg-white', 'text-ink-900')
        monthlyBtn.classList.add('text-white/70')
      }

      $$('.price-amount').forEach((el) => {
        const m = el.getAttribute('data-monthly')
        const y = el.getAttribute('data-yearly')
        el.textContent = yearly ? y : m
      })
      $$('.price-period').forEach((el) => {
        el.textContent = yearly ? ' (yearly)' : ''
      })
      $$('.price-billed').forEach((el) => {
        el.textContent = yearly ? 'Billed yearly · save 20%' : 'Billed monthly'
      })
    }

    on(monthlyBtn, 'click', () => setMode('monthly'))
    on(yearlyBtn, 'click', () => setMode('yearly'))
  }

  // -----------------------------
  // 10. Animated counters
  // -----------------------------
  function initCounters() {
    const counters = $$('.counter')
    if (!counters.length) return
    if (!('IntersectionObserver' in window) || prefersReducedMotion) {
      counters.forEach((c) => {
        c.textContent = c.getAttribute('data-target')
      })
      return
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return
        const el = entry.target
        const target = parseFloat(el.getAttribute('data-target') || '0')
        const isFloat = (el.getAttribute('data-target') || '').indexOf('.') !== -1
        const dur = 1600
        const start = performance.now()
        function tick(now) {
          const t = Math.min(1, (now - start) / dur)
          // ease-out cubic
          const eased = 1 - Math.pow(1 - t, 3)
          const v = target * eased
          el.textContent = isFloat
            ? v.toFixed(1)
            : formatInt(Math.round(v))
          if (t < 1) requestAnimationFrame(tick)
          else el.textContent = isFloat ? target.toFixed(1) : formatInt(target)
        }
        requestAnimationFrame(tick)
        io.unobserve(el)
      })
    }, { threshold: 0.4 })
    counters.forEach((c) => io.observe(c))

    function formatInt(n) {
      // 120000 -> "120,000" but if value is small, plain
      if (n >= 1000) return n.toLocaleString('en-IN')
      return String(n)
    }
  }

  // -----------------------------
  // 11. Contact form
  // -----------------------------
  function initContactForm() {
    const form = $('#contact-form')
    if (!form) return
    const fields = ['name', 'email', 'phone', 'business', 'shops', 'message']
    const ids = {
      name: 'cf-name', email: 'cf-email', phone: 'cf-phone',
      business: 'cf-business', shops: 'cf-shops', message: 'cf-message',
    }
    const submitBtn = $('#cf-submit')
    const successBox = $('#cf-success')
    const errorBanner = $('#cf-error-banner')

    function showError(name, show) {
      const el = $(`.cf-error[data-for="${name}"]`)
      const input = $('#' + ids[name])
      if (el) el.classList.toggle('hidden', !show)
      if (input) input.classList.toggle('is-invalid', !!show)
    }

    function getValues() {
      return fields.reduce((acc, f) => {
        const el = $('#' + ids[f])
        acc[f] = el ? el.value.trim() : ''
        return acc
      }, {})
    }

    function validate(v) {
      const errs = {}
      if (!v.name) errs.name = true
      if (!v.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) errs.email = true
      if (!v.phone || v.phone.replace(/\D/g, '').length < 8) errs.phone = true
      if (!v.business) errs.business = true
      if (!v.shops) errs.shops = true
      if (!v.message || v.message.length < 5) errs.message = true
      return errs
    }

    // Live clear on input
    fields.forEach((f) => {
      const el = $('#' + ids[f])
      if (!el) return
      on(el, 'input', () => showError(f, false))
      on(el, 'change', () => showError(f, false))
    })

    on(form, 'submit', async (ev) => {
      ev.preventDefault()
      successBox && successBox.classList.add('hidden')
      errorBanner && errorBanner.classList.add('hidden')

      const values = getValues()
      const errs = validate(values)
      fields.forEach((f) => showError(f, !!errs[f]))
      if (Object.keys(errs).length) {
        // Focus first invalid
        const first = fields.find((f) => errs[f])
        const el = $('#' + ids[first])
        if (el && el.focus) el.focus()
        return
      }

      // Show loading
      if (submitBtn) {
        submitBtn.disabled = true
        $$('.cf-label', form).forEach((s) => s.classList.add('hidden'))
        const sp = $('.cf-spinner', form)
        if (sp) sp.classList.remove('hidden')
      }

      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(values),
        })
        const data = await res.json().catch(() => ({}))
        if (res.ok && data && data.ok) {
          form.reset()
          successBox && successBox.classList.remove('hidden')
          successBox && successBox.scrollIntoView({ behavior: 'smooth', block: 'center' })
        } else {
          if (data && data.errors) {
            Object.keys(data.errors).forEach((k) => showError(k, true))
          } else {
            errorBanner && errorBanner.classList.remove('hidden')
          }
        }
      } catch (e) {
        errorBanner && errorBanner.classList.remove('hidden')
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false
          $$('.cf-label', form).forEach((s) => s.classList.remove('hidden'))
          const sp = $('.cf-spinner', form)
          if (sp) sp.classList.add('hidden')
        }
      }
    })
  }

  // -----------------------------
  // 12. Smooth-scroll for in-page anchors with offset
  // -----------------------------
  function initAnchorScroll() {
    $$('a[href^="#"]').forEach((a) => {
      on(a, 'click', (e) => {
        const href = a.getAttribute('href')
        if (!href || href === '#' || href.length < 2) return
        const target = document.querySelector(href)
        if (!target) return
        e.preventDefault()
        const top = target.getBoundingClientRect().top + window.scrollY - 90
        window.scrollTo({ top, behavior: prefersReducedMotion ? 'auto' : 'smooth' })
      })
    })
  }

  // -----------------------------
  // 13. GSAP enhancements (optional, only if GSAP loaded)
  // -----------------------------
  function initGSAP() {
    if (prefersReducedMotion) return
    if (typeof window.gsap === 'undefined') return
    try {
      if (window.ScrollTrigger) gsap.registerPlugin(window.ScrollTrigger)

      // Subtle parallax on hero blobs
      const blobs = $$('#hero .absolute.rounded-full')
      blobs.forEach((b, i) => {
        gsap.to(b, {
          yPercent: i % 2 === 0 ? -12 : 12,
          ease: 'none',
          scrollTrigger: {
            trigger: '#hero',
            start: 'top top',
            end: 'bottom top',
            scrub: 0.6,
          },
        })
      })

      // Floating mini cards drift
      $$('#hero .animate-float').forEach((el, i) => {
        gsap.to(el, {
          y: i === 0 ? -8 : 6,
          duration: 3 + i,
          ease: 'sine.inOut',
          yoyo: true,
          repeat: -1,
        })
      })
    } catch (e) {
      // Silently ignore — animations are progressive enhancement
    }
  }

  // -----------------------------
  // Boot
  // -----------------------------
  function boot() {
    try { initReveal() } catch (e) {}
    try { initScrollProgress() } catch (e) {}
    try { initNavbar() } catch (e) {}
    try { initStickyCTA() } catch (e) {}
    try { initCursor() } catch (e) {}
    try { initDemo() } catch (e) {}
    try { initCodeTabs() } catch (e) {}
    try { initFAQ() } catch (e) {}
    try { initPricing() } catch (e) {}
    try { initCounters() } catch (e) {}
    try { initContactForm() } catch (e) {}
    try { initAnchorScroll() } catch (e) {}
  }

  if (document.readyState === 'loading') {
    on(document, 'DOMContentLoaded', boot)
  } else {
    boot()
  }
  // GSAP loads with `defer` after this file; init it on full load
  on(window, 'load', () => {
    try { initGSAP() } catch (e) {}
  })
})()
