# MobiManager — Premium SaaS Landing Page

## Project Overview
- **Name**: MobiManager
- **Goal**: A production-ready, conversion-optimized SaaS landing page for MobiManager — the all-in-one business OS for mobile shops (sales, repairs, inventory, recharge, reports, staff permissions, audit trail, multi-shop, AI assistant).
- **Audience**: Shop owners/admins, sub-admin staff, and multi-branch (franchise) operators.

## Live URLs
- **Sandbox preview**: https://3000-ip8l33287walhhzqeltrm-b237eb32.sandbox.novita.ai
- **Local**: http://localhost:3000
- **Health check**: `/api/health`
- **Contact form API**: `POST /api/contact`

## Completed Features (all 16 mandatory sections)

1. **Sticky glass-morphism Navbar** — scroll state, mobile menu animation, in-page anchor scroll with offset
2. **Hero** — animated gradient mesh, headline with gradient + underline, dual CTA, dashboard preview (sidebar + KPI cards + sales chart + repair pipeline + floating mini-cards)
3. **Trust Bar** — placeholder logos + “Audit-ready · Multi-shop · Role-based access · Secure by design · Edge-fast” badges
4. **Features (9 modules)** — Repair Pipeline, Inventory & Valuation, Sales & Payments, Recharge Commissions, Reports & P&L, Staff & Permissions, Audit Trail, Multi-shop Switcher, AI Assistant (Elite)
5. **How It Works** — 4-step flow (Set up → Track → Review → Optimize) with connecting line + bullet points
6. **Interactive Demo** — fully simulated repair flow (RECEIVED → IN_REPAIR → REPAIRED → DELIVERED) with live status pill, progress bar, message updates, profit reveal, prev/next/reset and auto-advance on first view
7. **Benefits** — 4 outcome stat cards (revenue leakage, decision speed, profit clarity, accountability) + bullet list
8. **Comparison Table** — Paper / Excel / Generic POS / WhatsApp vs **MobiManager** across 8 features
9. **Developer / Integrations** — REST + Webhook + SDK code-snippet tabs with copy-to-clipboard (with execCommand fallback)
10. **Use Cases** — Single-store / Multi-branch / Accessory-heavy / High-volume recharge
11. **Security & Trust** — 6 cards (RBAC, audit trail, secure sessions, privacy, backups, sane defaults)
12. **Analytics Dashboard Preview** — animated counters + sales area chart + revenue-mix donut
13. **Pricing** — Free / Pro (most popular) / Enterprise with monthly/yearly toggle (20% save) + Elite AI add-on
14. **FAQ** — 8 accordion questions covering all required topics
15. **Multiple CTAs** — Hero, Mid-page, near pricing, Final, plus floating Sticky-CTA after scroll
16. **Contact form + footer** — validated lead form (name, email, phone, business, # of shops, message), full footer with 4 link columns + socials

### Premium UX details
- Scroll-progress bar (top of viewport)
- Custom mix-blend cursor with hover-grow ring (desktop only, hidden on touch)
- Section reveal-on-scroll (IntersectionObserver) — content stays visible if JS fails (fail-safe)
- Animated counters (ease-out cubic, IN locale formatting)
- Parallax hero blobs via GSAP ScrollTrigger (progressive enhancement)
- Glassmorphism, gradient meshes, subtle SVG noise overlay
- Fully responsive (mobile, tablet, desktop)
- `prefers-reduced-motion` honored — instant render, no animations
- Focus-visible outlines and ARIA-friendly mobile menu / FAQ

## Functional Entry URIs

| Method | Path                | Purpose                                                               |
| ------ | ------------------- | --------------------------------------------------------------------- |
| GET    | `/`                 | Renders the full landing page (SSR via Hono JSX renderer)             |
| GET    | `/static/style.css` | Premium stylesheet (animations, glass, accordion, sticky CTA, etc.)   |
| GET    | `/static/app.js`    | All client-side interactions (reveal, demo, pricing, FAQ, form, etc.) |
| GET    | `/api/health`       | Health JSON `{ ok: true, service: "mobimanager-landing" }`            |
| POST   | `/api/contact`      | Validates contact form payload; returns `{ ok, id }` or `{ ok:false, errors }` |

### Anchor links (in-page navigation)
`#hero`, `#features`, `#how-it-works`, `#demo`, `#pricing`, `#faq`, `#contact`

### CTA targets
- **Start free** → `/admin/register`
- **Book a demo / Get pricing** → `#contact`
- **Talk to sales** → `#contact`

## Data Architecture
- **Form payload**: `{ name, email, phone, business, shops, message }`
- **Server validation**: regex email, min phone digits, required fields. Returns granular field errors.
- **Storage**: currently in-memory mock (returns generated `enq_xxx` id). Swap-in points clearly marked for **Cloudflare D1** (relational lead store) or **KV** (rate limiting / submission throttle).
- **Static assets** served via Hono on Cloudflare Pages from `public/static/*`.

## User Guide
1. Visit `/` — the full landing page renders immediately (no blocking loader, no blank screen).
2. Scroll through the 16 sections; the scroll-progress bar tracks position.
3. Use the navbar (or mobile menu) to jump to **Features**, **How it works**, **Demo**, **Pricing**, **FAQ**.
4. In the **Demo** section, click **Next step** (or the steps themselves) to walk a repair from intake → delivery and see the profit reveal.
5. In **Developer**, switch tabs (REST / Webhook / SDK) and click **Copy** to copy code.
6. In **Pricing**, toggle **Monthly / Yearly** to see the 20% saving.
7. Submit the **Contact** form — invalid fields highlight inline, valid submissions show a success banner.

## Features Not Yet Implemented
- Real persistence for contact submissions (D1 / Resend email).
- Auth-protected `/admin/register` and `/dashboard` routes (out of scope for landing page).
- Production Tailwind build (currently CDN dev mode — works fine, but a PostCSS pipeline would shave bundle size).
- Internationalization (English only at the moment).
- Cookie banner / GDPR consent.

## Recommended Next Steps
1. Add a Cloudflare D1 binding and persist `/api/contact` submissions (`leads` table).
2. Wire `/api/contact` to a transactional email provider (Resend / SendGrid) for instant sales notification.
3. Replace Tailwind CDN with a PostCSS build for production (eliminate the dev-mode warning).
4. Add OG image (`/static/og.png`) for social sharing.
5. Hook the GA / PostHog analytics snippet into `renderer.tsx`.
6. Wire the actual `/admin/register` and `/dashboard` apps so CTAs go to real product surfaces.
7. Add E2E tests (Playwright) covering nav, demo, pricing toggle, FAQ, and form submission.

## Tech Stack
- **Framework**: Hono 4 + JSX renderer (SSR)
- **Build**: Vite 6 + `@hono/vite-build/cloudflare-pages`
- **Runtime**: Cloudflare Pages (Workers runtime)
- **Styling**: Tailwind CSS (CDN) + custom CSS (glassmorphism, gradients, accordion, custom cursor)
- **Animations**: GSAP + ScrollTrigger (progressive enhancement), CSS keyframes, IntersectionObserver
- **Icons**: Font Awesome 6
- **Fonts**: Inter (sans), Space Grotesk (display), JetBrains Mono (code)
- **Process manager (dev)**: PM2

## Development

```bash
# Build
npm run build

# Run via PM2 (sandbox-friendly, non-blocking)
pm2 start ecosystem.config.cjs

# Logs (non-blocking)
pm2 logs webapp --nostream

# Test
curl http://localhost:3000
curl -X POST http://localhost:3000/api/contact \
  -H "Content-Type: application/json" \
  -d '{"name":"Aarav","email":"a@b.com","phone":"9876543210","business":"CityCell","shops":"1","message":"Want a demo"}'
```

## Project Structure

```
webapp/
├── src/
│   ├── index.tsx              # Hono app + routes (/, /api/contact, /api/health)
│   ├── renderer.tsx           # HTML shell, head tags, Tailwind config, fonts, GSAP
│   └── components/
│       ├── Navbar.tsx
│       ├── Hero.tsx
│       ├── TrustBar.tsx
│       ├── Features.tsx
│       ├── HowItWorks.tsx
│       ├── InteractiveDemo.tsx
│       ├── Benefits.tsx
│       ├── Comparison.tsx
│       ├── Developer.tsx
│       ├── UseCases.tsx
│       ├── Security.tsx
│       ├── Analytics.tsx
│       ├── Pricing.tsx
│       ├── FAQ.tsx
│       ├── CTASections.tsx    # MidCTA + FinalCTA
│       ├── Contact.tsx
│       └── Footer.tsx         # Footer + StickyCTA
├── public/static/
│   ├── style.css              # Premium styles, animations, accordion, cursor
│   └── app.js                 # All client-side interactions (~20kb, single file, defer-loaded)
├── ecosystem.config.cjs       # PM2 config
├── wrangler.jsonc             # Cloudflare Pages config
├── vite.config.ts
└── package.json
```

## Bug-Prevention Guarantees
- ✅ Page **never blank-screens** — content renders without JS, without CSS, without animations.
- ✅ Reveal animations have a 2-second safety net that force-shows any element not yet revealed.
- ✅ Every interaction (`copy`, `fetch`, `IntersectionObserver`) has a try/catch and a fallback.
- ✅ `prefers-reduced-motion` skips all animations and runs instantly.
- ✅ Touch devices auto-disable the custom cursor.
- ✅ Form validation runs client-side AND server-side; either failure mode degrades gracefully.
- ✅ **Zero JavaScript errors** confirmed in headless-browser testing.

## Deployment
- **Platform**: Cloudflare Pages
- **Status**: Local sandbox build verified — `200 OK`, ~113 kB HTML, no JS errors
- **Last Updated**: 2026-05-09
