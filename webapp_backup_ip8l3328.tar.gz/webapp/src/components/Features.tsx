export const Features = () => {
  const features = [
    {
      icon: 'fa-screwdriver-wrench',
      title: 'Repair Pipeline',
      desc: 'Status flow from RECEIVED → IN_REPAIR → REPAIRED → DELIVERED with pending pickup alerts and per-job profitability.',
      color: 'from-amber-500/20 to-orange-500/10',
      iconColor: 'text-amber-300',
      tag: 'Operations',
    },
    {
      icon: 'fa-boxes-stacked',
      title: 'Inventory & Valuation',
      desc: 'Live stock, low-stock & out-of-stock alerts, plus cost vs selling valuation for every product.',
      color: 'from-rose-500/20 to-fuchsia-500/10',
      iconColor: 'text-rose-300',
      tag: 'Stock',
    },
    {
      icon: 'fa-cart-shopping',
      title: 'Sales & Payments',
      desc: 'Quick-create sales with CASH, UPI, CARD or CREDIT, line discounts, search and filterable history.',
      color: 'from-emerald-500/20 to-teal-500/10',
      iconColor: 'text-emerald-300',
      tag: 'Revenue',
    },
    {
      icon: 'fa-mobile-retro',
      title: 'Recharge Commissions',
      desc: 'Pending / success / failed transaction logs with per-operator commission tracking and audit-safe edits.',
      color: 'from-cyan-500/20 to-sky-500/10',
      iconColor: 'text-cyan-300',
      tag: 'Telecom',
    },
    {
      icon: 'fa-chart-line',
      title: 'Reports & P&L',
      desc: 'Investor-ready overview plus deep reports on Sales, Repairs, Recharge, Inventory and Profit & Loss.',
      color: 'from-violet-500/20 to-indigo-500/10',
      iconColor: 'text-violet-300',
      tag: 'Insights',
    },
    {
      icon: 'fa-users-gear',
      title: 'Staff & Permissions',
      desc: 'Sub-admin roles, granular module permissions, activation control and plan-based seat limits.',
      color: 'from-pink-500/20 to-rose-500/10',
      iconColor: 'text-pink-300',
      tag: 'Team',
    },
    {
      icon: 'fa-clock-rotate-left',
      title: 'Audit Trail',
      desc: 'Every sensitive edit (recharge corrections, refunds) is logged with who, what and reason.',
      color: 'from-blue-500/20 to-indigo-500/10',
      iconColor: 'text-blue-300',
      tag: 'Trust',
    },
    {
      icon: 'fa-store',
      title: 'Multi-shop Switcher',
      desc: 'Run multiple branches under one account with a single switcher and per-shop reporting.',
      color: 'from-lime-500/20 to-green-500/10',
      iconColor: 'text-lime-300',
      tag: 'Scale',
    },
    {
      icon: 'fa-wand-magic-sparkles',
      title: 'AI Assistant · Elite',
      desc: 'Festival offers, slow-stock advice, social captions and monthly strategy with usage meter & language selector.',
      color: 'from-purple-500/20 to-pink-500/10',
      iconColor: 'text-purple-300',
      tag: 'Elite',
      elite: true,
    },
  ]

  return (
    <section id="features" class="relative py-24 sm:py-32">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-2xl">
          <span data-anim="fade-up" class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">
            <i class="fas fa-layer-group text-brand-300"></i> Modules
          </span>
          <h2 data-anim="fade-up" class="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
            Every workflow your mobile shop runs on — in one place.
          </h2>
          <p data-anim="fade-up" class="mt-4 text-white/60 text-base sm:text-lg">
            Generic POS tools force you to bolt on repairs, recharge and audit. MobiManager is purpose-built so all the modules talk to each other natively.
          </p>
        </div>

        {/* Cards */}
        <div class="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <div
              data-anim="fade-up"
              data-anim-delay={(i * 0.05).toString()}
              class="group feature-card relative rounded-2xl border border-white/10 bg-gradient-to-b from-ink-800/60 to-ink-900/60 p-6 hover:border-white/20 transition-all overflow-hidden"
            >
              {/* Hover glow */}
              <div class={`absolute inset-0 bg-gradient-to-br ${f.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
              <div class="absolute -top-32 -right-32 w-64 h-64 bg-brand-500/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity"></div>

              <div class="relative">
                <div class="flex items-center justify-between">
                  <div class={`w-12 h-12 rounded-xl border border-white/10 bg-ink-800/80 flex items-center justify-center ${f.iconColor} group-hover:scale-110 transition-transform duration-300`}>
                    <i class={`fas ${f.icon} text-lg`}></i>
                  </div>
                  <span class={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border ${f.elite ? 'border-purple-400/40 text-purple-300 bg-purple-500/10' : 'border-white/10 text-white/50'}`}>
                    {f.tag}
                  </span>
                </div>
                <h3 class="mt-5 font-display text-xl font-semibold">{f.title}</h3>
                <p class="mt-2 text-sm text-white/60 leading-relaxed">{f.desc}</p>

                <div class="mt-5 flex items-center gap-1.5 text-xs text-white/50 group-hover:text-white transition-colors">
                  Learn more
                  <i class="fas fa-arrow-right text-[10px] group-hover:translate-x-0.5 transition-transform"></i>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
