export const Developer = () => {
  const restSnippet = `// Create a new repair job
fetch("https://api.mobimanager.io/v1/repairs", {
  method: "POST",
  headers: {
    "Authorization": "Bearer \${API_KEY}",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    shop_id: "shp_8sZ",
    device:  "iPhone 13",
    issue:   "screen_replacement",
    customer: { name: "Aarav", phone: "98xxxxxx21" }
  })
})
.then(r => r.json())
.then(job => console.log(job.status)) // "RECEIVED"`

  const webhookSnippet = `// Listen for status updates
app.post("/webhooks/mobimanager", (req, res) => {
  const event = req.body;
  if (event.type === "repair.status_changed") {
    notifyCustomer(event.data.customer_phone, event.data.status);
  }
  res.status(200).send("ok");
});`

  const sdkSnippet = `// Node SDK (preview)
import { MobiManager } from "@mobimanager/sdk";

const mm = new MobiManager(process.env.MM_KEY);

const sale = await mm.sales.create({
  shop_id: "shp_8sZ",
  items: [{ sku: "PHN-CASE-13", qty: 1, price: 499 }],
  payment_mode: "UPI"
});`

  return (
    <section class="relative py-24 sm:py-32">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          <div>
            <span data-anim="fade-up" class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">
              <i class="fas fa-code text-emerald-300"></i> Integrations & extensibility
            </span>
            <h2 data-anim="fade-up" class="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              An API the rest of your stack can talk to.
            </h2>
            <p data-anim="fade-up" class="mt-4 text-white/60 text-base sm:text-lg leading-relaxed">
              Email service, file uploads, accounting exports and a clean REST API make MobiManager easy to extend.
              Webhooks keep your downstream systems in sync — without polling.
            </p>
            <div data-anim="fade-up" class="mt-6 grid grid-cols-2 gap-3 max-w-md">
              {[
                { i: 'fa-envelope', l: 'Email service' },
                { i: 'fa-cloud-arrow-up', l: 'File uploads' },
                { i: 'fa-bolt', l: 'Webhooks' },
                { i: 'fa-file-export', l: 'CSV / accounting' },
              ].map((x) => (
                <div class="rounded-xl border border-white/10 bg-ink-800/50 px-3 py-2.5 text-xs text-white/70 inline-flex items-center gap-2">
                  <i class={`fas ${x.i} text-brand-300`}></i> {x.l}
                </div>
              ))}
            </div>
          </div>

          <div data-anim="fade-up" class="relative">
            <div class="absolute -inset-x-10 -top-10 -bottom-10 bg-gradient-to-r from-brand-600/20 to-accent-500/20 blur-3xl -z-10"></div>
            <div class="rounded-2xl border border-white/10 bg-ink-900/80 backdrop-blur overflow-hidden shadow-2xl">
              {/* Tabs */}
              <div class="flex items-center justify-between px-2 py-2 border-b border-white/5 bg-ink-800/60">
                <div class="flex items-center gap-1" role="tablist">
                  <button data-tab="rest" class="code-tab text-xs px-3 py-1.5 rounded-md bg-white/10 text-white">REST</button>
                  <button data-tab="webhook" class="code-tab text-xs px-3 py-1.5 rounded-md text-white/55 hover:text-white">Webhook</button>
                  <button data-tab="sdk" class="code-tab text-xs px-3 py-1.5 rounded-md text-white/55 hover:text-white">SDK</button>
                </div>
                <button id="copy-code" type="button" class="text-xs px-3 py-1.5 rounded-md text-white/60 hover:text-white hover:bg-white/5 inline-flex items-center gap-1.5">
                  <i class="far fa-copy"></i> <span id="copy-label">Copy</span>
                </button>
              </div>

              <pre data-pane="rest" class="code-pane p-5 text-[12.5px] leading-relaxed text-white/85 font-mono overflow-x-auto m-0"><code>{restSnippet}</code></pre>
              <pre data-pane="webhook" class="code-pane hidden p-5 text-[12.5px] leading-relaxed text-white/85 font-mono overflow-x-auto m-0"><code>{webhookSnippet}</code></pre>
              <pre data-pane="sdk" class="code-pane hidden p-5 text-[12.5px] leading-relaxed text-white/85 font-mono overflow-x-auto m-0"><code>{sdkSnippet}</code></pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
