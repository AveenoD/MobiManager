export const Pricing = () => {
  const tiers = [
    {
      name: 'Starter',
      tag: 'Free',
      monthly: 0,
      yearly: 0,
      desc: 'Get up and running with the essentials of a single mobile shop.',
      features: [
        'Sales, repairs & inventory',
        'Up to 1 shop',
        '1 admin user',
        'Daily dashboard overview',
        'Basic reports',
      ],
      cta: 'Start free',
      ctaHref: '/admin/register',
      highlight: false,
    },
    {
      name: 'Pro',
      tag: 'Most popular',
      monthly: 999,
      yearly: 799,
      desc: 'For growing shops that need staff, recharge tracking and deeper reports.',
      features: [
        'Everything in Starter',
        'Up to 3 sub-admins (staff)',
        'Recharge & commission tracking',
        'Advanced reports + P&L',
        'Audit trail',
        'Email support',
      ],
      cta: 'Start 14-day trial',
      ctaHref: '/admin/register',
      highlight: true,
    },
    {
      name: 'Enterprise',
      tag: 'Multi-shop',
      monthly: 2499,
      yearly: 1999,
      desc: 'For multi-branch operators who need control, accountability and priority support.',
      features: [
        'Everything in Pro',
        'Unlimited shops',
        'Unlimited sub-admins',
        'Advanced permission controls',
        'Priority support + SLA',
        'CSV / accounting exports',
      ],
      cta: 'Talk to sales',
      ctaHref: '#contact',
      highlight: false,
    },
  ]

  return (
    <section id="pricing" class="relative py-24 sm:py-32">
      <div class="absolute inset-0 -z-10 overflow-hidden">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full bg-gradient-to-br from-brand-600/10 via-accent-500/10 to-transparent blur-3xl"></div>
      </div>
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-2xl mx-auto">
          <span data-anim="fade-up" class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">
            <i class="fas fa-tag text-brand-300"></i> Pricing
          </span>
          <h2 data-anim="fade-up" class="mt-4 font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
            Simple, honest pricing.
          </h2>
          <p data-anim="fade-up" class="mt-4 text-white/60">
            Start free. Upgrade only when you outgrow it. Cancel anytime.
          </p>

          {/* Toggle */}
          <div data-anim="fade-up" class="mt-7 inline-flex items-center gap-1 p-1 rounded-full border border-white/10 bg-ink-800/60">
            <button id="bill-monthly" type="button" class="bill-toggle px-4 py-1.5 rounded-full text-sm bg-white text-ink-900 font-semibold transition-all">Monthly</button>
            <button id="bill-yearly" type="button" class="bill-toggle px-4 py-1.5 rounded-full text-sm text-white/70 hover:text-white inline-flex items-center gap-1.5 transition-all">
              Yearly
              <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/20">Save 20%</span>
            </button>
          </div>
        </div>

        {/* Tiers */}
        <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-5 max-w-6xl mx-auto">
          {tiers.map((t, i) => (
            <div
              data-anim="fade-up"
              data-anim-delay={(i * 0.06).toString()}
              class={`relative rounded-2xl border p-6 sm:p-7 flex flex-col ${
                t.highlight
                  ? 'border-brand-400/40 bg-gradient-to-b from-brand-500/[0.12] to-ink-900/60 shadow-[0_20px_60px_-20px_rgba(99,102,241,0.4)]'
                  : 'border-white/10 bg-ink-800/40 hover:border-white/20'
              } transition-colors`}
            >
              {t.highlight && (
                <div class="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[11px] font-semibold bg-gradient-to-r from-brand-500 to-accent-400 text-white shadow-lg">
                  <i class="fas fa-star text-[9px] mr-1"></i> {t.tag}
                </div>
              )}

              <div class="flex items-baseline justify-between">
                <h3 class="font-display text-xl font-bold">{t.name}</h3>
                {!t.highlight && (
                  <span class="text-[10px] uppercase tracking-wider text-white/45">{t.tag}</span>
                )}
              </div>
              <p class="mt-2 text-sm text-white/55 leading-relaxed">{t.desc}</p>

              <div class="mt-6 flex items-end gap-1.5">
                {t.monthly === 0 ? (
                  <span class="font-display text-5xl font-bold">Free</span>
                ) : (
                  <>
                    <span class="text-2xl text-white/60">₹</span>
                    <span
                      class="font-display text-5xl font-bold price-amount"
                      data-monthly={t.monthly.toString()}
                      data-yearly={t.yearly.toString()}
                    >
                      {t.monthly}
                    </span>
                    <span class="text-sm text-white/50 mb-1.5">
                      / mo<span class="price-period"></span>
                    </span>
                  </>
                )}
              </div>
              {t.monthly > 0 && (
                <div class="text-xs text-white/40 mt-1 price-billed">
                  Billed monthly
                </div>
              )}

              <a
                href={t.ctaHref}
                class={`mt-6 inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition-all ${
                  t.highlight
                    ? 'bg-white text-ink-900 hover:bg-white/90 shadow-[0_10px_40px_-10px_rgba(255,255,255,0.4)]'
                    : 'border border-white/15 bg-white/5 hover:bg-white/10 text-white'
                }`}
              >
                {t.cta} <i class="fas fa-arrow-right text-xs"></i>
              </a>

              <ul class="mt-6 space-y-2.5 text-sm">
                {t.features.map((f) => (
                  <li class="flex items-start gap-2.5 text-white/75">
                    <i class={`fas fa-check mt-1 text-xs ${t.highlight ? 'text-brand-300' : 'text-emerald-400'}`}></i>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Elite add-on */}
        <div data-anim="fade-up" class="mt-8 max-w-6xl mx-auto rounded-2xl border border-purple-400/20 bg-gradient-to-r from-purple-500/10 via-fuchsia-500/5 to-transparent p-6 sm:p-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div class="flex items-start gap-4">
            <div class="w-12 h-12 shrink-0 rounded-xl bg-gradient-to-br from-purple-500/30 to-fuchsia-500/30 border border-purple-400/30 flex items-center justify-center text-purple-200">
              <i class="fas fa-wand-magic-sparkles"></i>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-display text-lg font-bold">Elite · AI Assistant</h3>
                <span class="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border border-purple-400/30 text-purple-200 bg-purple-500/10">Add-on</span>
              </div>
              <p class="mt-1 text-sm text-white/65 max-w-2xl">
                Festival offers, slow-stock advice, social captions and a monthly strategy report — with usage limits, language selector and an upgrade-aware paywall.
              </p>
            </div>
          </div>
          <a href="#contact" class="shrink-0 inline-flex items-center gap-2 rounded-xl bg-purple-500/90 hover:bg-purple-500 text-white px-5 py-3 text-sm font-semibold">
            Add Elite <i class="fas fa-arrow-right text-xs"></i>
          </a>
        </div>

        <p class="mt-6 text-center text-xs text-white/40">
          <i class="fas fa-shield-halved mr-1 text-emerald-400/80"></i>
          14-day free trial on Pro · Cancel anytime · No card required
        </p>
      </div>
    </section>
  )
}
