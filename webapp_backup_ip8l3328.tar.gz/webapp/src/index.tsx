import { Hono } from 'hono'
import { renderer } from './renderer'
import { Navbar } from './components/Navbar'
import { Hero } from './components/Hero'
import { TrustBar } from './components/TrustBar'
import { Features } from './components/Features'
import { HowItWorks } from './components/HowItWorks'
import { InteractiveDemo } from './components/InteractiveDemo'
import { Benefits } from './components/Benefits'
import { Comparison } from './components/Comparison'
import { Developer } from './components/Developer'
import { UseCases } from './components/UseCases'
import { Security } from './components/Security'
import { Analytics } from './components/Analytics'
import { Pricing } from './components/Pricing'
import { FAQ } from './components/FAQ'
import { MidCTA, FinalCTA } from './components/CTASections'
import { Contact } from './components/Contact'
import { Footer, StickyCTA } from './components/Footer'

const app = new Hono()

app.use(renderer)

app.get('/', (c) => {
  return c.render(
    <>
      <Navbar />
      <main>
        <Hero />
        <TrustBar />
        <Features />
        <HowItWorks />
        <InteractiveDemo />
        <Benefits />
        <Comparison />
        <MidCTA />
        <Developer />
        <UseCases />
        <Security />
        <Analytics />
        <Pricing />
        <FAQ />
        <Contact />
        <FinalCTA />
      </main>
      <Footer />
      <StickyCTA />
    </>
  )
})

// Contact form API endpoint — safe local mock that never errors
app.post('/api/contact', async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}))
    const name = (body?.name ?? '').toString().trim()
    const email = (body?.email ?? '').toString().trim()
    const phone = (body?.phone ?? '').toString().trim()
    const business = (body?.business ?? '').toString().trim()
    const shops = (body?.shops ?? '').toString().trim()
    const message = (body?.message ?? '').toString().trim()

    const errors: Record<string, string> = {}
    if (!name) errors.name = 'Name is required'
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'Valid email required'
    if (!phone || phone.replace(/\D/g, '').length < 8) errors.phone = 'Valid phone required'
    if (!business) errors.business = 'Business name required'
    if (!shops) errors.shops = 'Please select an option'
    if (!message || message.length < 5) errors.message = 'Tell us a bit more'

    if (Object.keys(errors).length) {
      return c.json({ ok: false, errors }, 400)
    }

    // Mock success — in production this would persist to D1 / send email
    return c.json({
      ok: true,
      id: 'enq_' + Math.random().toString(36).slice(2, 10),
      received_at: new Date().toISOString(),
    })
  } catch (e) {
    return c.json({ ok: false, error: 'Unexpected error' }, 500)
  }
})

// Health
app.get('/api/health', (c) => c.json({ ok: true, service: 'mobimanager-landing' }))

export default app
